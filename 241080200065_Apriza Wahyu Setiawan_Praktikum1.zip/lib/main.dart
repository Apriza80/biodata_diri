import 'package:flutter/material.dart';

// Class Mahasiswa yang diperluas sesuai instruksi tugas
class Mahasiswa {
  String nama;
  String nim;
  String prodi;
  String semester;
  String kota;
  String hobi;
  String deskripsiDiri;
  String keahlian;

  Mahasiswa({
    required this.nama,
    required this.nim,
    required this.prodi,
    required this.semester,
    required this.kota,
    required this.hobi,
    required this.deskripsiDiri,
    required this.keahlian,
  });

  // Method tampilkan() untuk mengembalikan ringkasan data
  String tampilkan() {
    return 'Nama: $nama\nNIM: $nim\nProdi: $prodi\nSemester: $semester\nKota: $kota\nHobi: $hobi\nDeskripsi: $deskripsiDiri\nKeahlian: $keahlian';
  }
}

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Inisialisasi data mahasiswa
    Mahasiswa mhs = Mahasiswa(
      nama: 'Apriza Wahyu Setiawan',
      nim: '241080200065',
      prodi: 'Teknik Informatika',
      semester: '4',
      kota: 'Sidoarjo',
      hobi: 'Coding & Badminton',
      deskripsiDiri:
      'Mahasiswa Teknik Informatika yang antusias terhadap pengembangan aplikasi mobile dan web.',
      keahlian: 'Flutter, Dart, HTML/CSS, MySQL',
    );

    // Mengambil 2 inisial nama untuk avatar
    List<String> nameParts = mhs.nama.trim().split(' ');
    String initial = nameParts.length > 1
        ? '${nameParts[0][0]}${nameParts[1][0]}'
        : nameParts[0][0];

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Biodata Diri',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF1E3C72),
      ),
      home: Scaffold(
        backgroundColor: const Color(0xFFF0F4F8),
        appBar: AppBar(
          title: const Text(
            'Biodata Diri',
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
          ),
          centerTitle: true,
          backgroundColor: const Color(0xFF1E3C72),
          elevation: 0,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.08),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Header Card dengan Inisial Avatar
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(24),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFF1E3C72), Color(0xFF2A5298)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                      ),
                    ),
                    child: Column(
                      children: [
                        // Avatar Inisial Nama
                        CircleAvatar(
                          radius: 36,
                          backgroundColor: Colors.white,
                          child: Text(
                            initial,
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF1E3C72),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          mhs.nama,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${mhs.nim} | ${mhs.prodi}',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Informasi Detail (8 Informasi)
                  Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        _buildItemInfo(Icons.badge_outlined, 'NIM', mhs.nim),
                        _buildDivider(),
                        _buildItemInfo(Icons.school_outlined, 'Program Studi', mhs.prodi),
                        _buildDivider(),
                        _buildItemInfo(Icons.timeline_outlined, 'Semester', 'Semester ${mhs.semester}'),
                        _buildDivider(),
                        _buildItemInfo(Icons.location_city_outlined, 'Kota', mhs.kota),
                        _buildDivider(),
                        _buildItemInfo(Icons.sports_esports_outlined, 'Hobi', mhs.hobi),
                        _buildDivider(),
                        _buildItemInfo(Icons.code_outlined, 'Keahlian', mhs.keahlian),
                        _buildDivider(),
                        _buildItemInfo(Icons.description_outlined, 'Deskripsi Diri', mhs.deskripsiDiri),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDivider() {
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: 10),
      child: Divider(height: 1, color: Color(0xFFEEEEEE)),
    );
  }

  Widget _buildItemInfo(IconData icon, String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(9),
          decoration: BoxDecoration(
            color: const Color(0xFF1E3C72).withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: const Color(0xFF1E3C72), size: 20),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  fontSize: 11,
                  color: Colors.grey,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF222222),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}